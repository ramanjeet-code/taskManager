package com.taskManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardCompanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardCompanyApplication.class, args);
	}

}
