package com.taskManager.modules;

public enum TaskStatus {
    TODO, DONE
}
