package com.taskManager.modules;

public enum TaskPriority{
    LOW, MEDIUM, HIGH

}
