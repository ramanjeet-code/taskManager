package com.taskManager.exception;

public class SubTaskNotFoundException extends RuntimeException {
    public SubTaskNotFoundException(String message) {
        super(message);
    }
}

