package com.taskManager.exception;

public class RouteException extends Exception {

	public RouteException() {
		// TODO Auto-generated constructor stub
	}
	
	public RouteException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
}
