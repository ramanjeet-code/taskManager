package com.taskManager.exception;

public class LoginException extends Exception{

	public LoginException() {
		// TODO Auto-generated constructor stub
	}
	
	public LoginException(String msg) {
		super(msg);
	}
	
}
