package com.taskManager.authentication;

public class JwtConstant {
	public static final String SECRET_KEY = "jasjddafwqeqwesadasdwdqweqwddcgtgtyyj";
	public static final String  JWT_HEADER = "Authorization";
}	
